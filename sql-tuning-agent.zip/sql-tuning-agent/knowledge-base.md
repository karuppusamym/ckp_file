# Knowledge base — cross-DB SQL tuning lessons

This file is the agent's shared memory. Every run may append **one** compact lesson; the orchestrator dedupes by `id`. Read the top of the file first — it holds the highest-signal patterns. Newer lessons go at the bottom of each section.

Format for every lesson line:

```
- [<id>] <db_type> :: <symptom ≤10 words> :: <fix ≤15 words>
  before: <fragment>
  after:  <fragment>
```

Section headers group by root-cause category (matches `system-prompt.md` §3.2). The agent should match a new use case against the sections in order; the first matching lesson wins.

---

## 1. Predicate not sargable

- [TD-SARG-001] teradata :: CAST on join/filter key disables primary index :: coerce parameter side, not column side
  before: `WHERE CAST(loan_no AS VARCHAR(20)) = ?`
  after:  `WHERE loan_no = CAST(? AS DECIMAL(15,0))`

- [ORA-SARG-001] oracle :: TRUNC(date_col) disables index range scan :: rewrite as half-open range
  before: `WHERE TRUNC(created_at) = DATE '2026-01-15'`
  after:  `WHERE created_at >= DATE '2026-01-15' AND created_at < DATE '2026-01-16'`

- [MSS-SARG-001] sqlserver :: leading wildcard LIKE forces scan :: full-text search or trigram index, or reverse-store the column
  before: `WHERE name LIKE '%smith'`
  after:  (use FULLTEXT CONTAINS, or store reverse(name) and query LIKE 'htims%')

- [PG-SARG-001] postgres :: implicit int↔text cast on join key blocks index :: match declared types on both sides
  before: `ON o.customer_id = c.id_text  -- customer_id INT, id_text TEXT`
  after:  `ON o.customer_id = c.id_text::int  -- and add functional index on the join key`

## 2. Wrong access path

- [TD-ACC-001] teradata :: 50-row IN-list scanned as full table :: rewrite IN as inner join to a values table or volatile table with stats
  before: `WHERE loan_no IN (?, ?, ... x50)`
  after:  `CREATE VOLATILE TABLE ids (...) ON COMMIT PRESERVE ROWS; INSERT ... COLLECT STATISTICS ON ids COLUMN(loan_no); SELECT ... FROM t INNER JOIN ids USING(loan_no);`

- [ORA-ACC-001] oracle :: bind peeking picks wrong plan for skewed values :: use adaptive cursor sharing, or split by shape into two named queries

- [MSS-ACC-001] sqlserver :: parameter sniffing locks bad plan :: OPTION (RECOMPILE) on the problem statement, or OPTIMIZE FOR UNKNOWN when distribution is uniform

- [PG-ACC-001] postgres :: `NOT IN (subquery)` with nullable column returns nothing / slow :: use `NOT EXISTS`
  before: `WHERE x NOT IN (SELECT y FROM t WHERE y IS NOT NULL)`
  after:  `WHERE NOT EXISTS (SELECT 1 FROM t WHERE t.y = outer.x)`

## 3. Skewed or misordered joins

- [TD-JOIN-001] teradata :: hash join on non-PI key redistributes billions of rows :: pre-aggregate the large side, or add matching PI on the intermediate volatile table

- [ORA-JOIN-001] oracle :: nested loop on 100M×100M chosen for a small IN-list :: `/*+ USE_HASH(a b) */` only after confirming stats are current

- [MSS-JOIN-001] sqlserver :: 10-table single SELECT explodes cardinality :: split into 2–3 CTEs each filtered to <10k rows; force order only if CE misestimates persist

- [PG-JOIN-001] postgres :: cross-join from missing ON clause :: `SET enable_nestloop = off` masks the bug; find the missing predicate first

## 4. CTE / subquery materialization

- [TD-CTE-001] teradata :: CTE reused twice, optimizer inlines both :: promote to volatile table with COLLECT STATISTICS between insert and select
- [ORA-CTE-001] oracle :: WITH clause materializes even when inline is cheaper :: `/*+ INLINE */` on the CTE
- [MSS-CTE-001] sqlserver :: CTE always inlines (no MATERIALIZE hint) :: rewrite as `#temp` when reused ≥2 times
- [PG-CTE-001] postgres :: pre-12 CTEs always materialize (optimization fence) :: on ≥12 use `AS MATERIALIZED` / `AS NOT MATERIALIZED` explicitly

## 5. Aggregation before filtering

- [XDB-AGG-001] all :: GROUP BY over entire table then HAVING :: push filter into a CTE first, then aggregate
  before: `SELECT dept, SUM(amt) FROM txn GROUP BY dept HAVING dept = 'X'`
  after:  `WITH f AS (SELECT * FROM txn WHERE dept = 'X') SELECT dept, SUM(amt) FROM f GROUP BY dept`

- [XDB-WIN-001] all :: window function over unfiltered table :: filter in a CTE first; window functions can't use most indexes on their partition

## 6. History-table over-scan

- [XDB-HIST-001] all :: SCD-2 history joined without effective-date predicate :: every join to a `_HIST` table needs both endpoints
  before: `LEFT JOIN loan_hist h ON h.loan_no = c.loan_no`
  after:  `LEFT JOIN loan_hist h ON h.loan_no = c.loan_no AND CURRENT_DATE BETWEEN h.eff_start_dt AND h.eff_end_dt`

- [XDB-HIST-002] all :: point-in-time read touches history when a `_CURRENT` view exists :: prefer the current view; touch history only for as-of queries

## 7. Data type / collation drift

- [XDB-TYPE-001] all :: VARCHAR ↔ NUMBER join key causes implicit cast, disables index :: normalize types in DDL or coerce on the smaller side only
- [MSS-COLL-001] sqlserver :: mixed collations on join key force scan :: `COLLATE DATABASE_DEFAULT` on both sides, or fix DDL

## 8. Parameter-shape mismatch

- [XDB-SHAPE-001] all :: query optimal for 1 value degrades on 50-value IN-list :: two candidates, one per shape; recommend join-to-values for lists ≥ ~50
- [XDB-SHAPE-002] all :: TVP / table parameter beats string-split IN-list :: use a values-CTE or temp table populated by the caller

---

## How the agent uses this file

At diagnosis time, the agent scans this file for a lesson matching the current `db_type` + root cause. If found, it references the `id` in `lesson.duplicate_of` and skips writing a new lesson. If the pattern is a variant, it adds a new lesson with the next available id in the section (e.g. `TD-SARG-002`).

## Regression rule

Never remove a lesson without a superseding one. A lesson that turned out to be wrong gets a `superseded_by: <newer_id>` note appended to its line — the historical entry stays so the agent can recognize the anti-fix on future scans.
