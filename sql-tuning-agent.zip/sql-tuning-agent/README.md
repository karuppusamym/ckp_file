# SQL Query Tuning Agent

A prompt + folder convention for a Claude-driven SQL tuning agent that works across **Teradata, Oracle, SQL Server, PostgreSQL** (and can be extended). It reads a slow query, its DDL, its execution plan and its parameters, then produces either **one refined query** (when confident) or **2–3 ranked candidates**. It grows a shared **knowledge base** file across runs, so the next tuning attempt starts smarter than the last.

---

## 1. First-principles view: what is this actually doing?

A SQL tuning agent is a *diagnostic loop*, not a rewrite engine. The loop has four stages:

1. **Observe** — read what actually exists: the query, its schema, its plan, the parameter shape (single value vs. list of 50), the target DB engine.
2. **Diagnose** — decide what the slow part *is* (not what you'd guess). A plan with a nested-loop join on a 100M-row table is a different problem from a `NOT IN` against a subquery, which is different from a bind-variable mismatch causing a full scan.
3. **Prescribe** — rewrite. Rewrite honors DB-specific dialect, uses the right shape (single SELECT / CTE / temp table) for the diagnosis, and preserves the contract that the *last statement returns the same rows*.
4. **Remember** — log what worked and what didn't in the shared knowledge file, tagged by DB and symptom, so future runs can pattern-match.

That's the whole design. Everything below is the plumbing that makes the loop repeatable.

---

## 2. Folder layout

```
sql-tuning-agent/
├── README.md                    ← this file
├── system-prompt.md             ← the agent's system prompt (what you send to Claude)
├── knowledge-base.md            ← shared memory: symptoms → fixes, per-DB quirks (grows over time)
├── templates/
│   ├── usecase-index.csv        ← batch driver: one row per use case
│   ├── usecase-folder.md        ← what each use-case folder must contain
│   ├── input-envelope.md        ← the structured user-message the agent expects
│   └── output-envelope.md       ← the structured response the agent must return
├── references/
│   ├── teradata.md              ← engine-specific hints, anti-patterns, syntax
│   ├── oracle.md
│   ├── sqlserver.md
│   └── postgres.md
└── examples/
    └── loan-lookup/             ← a worked example use-case folder
        ├── existing.sql
        ├── ddl.sql
        ├── plan.txt
        ├── params.md
        └── notes.md
```

---

## 3. Two operating modes

### Mode A — Manual (one use case)

You (or a human tuner) invoke the agent for a single use case:

```
1. Point the agent at usecases/<name>/
2. It reads existing.sql, ddl.sql, plan.txt, params.md, notes.md
3. It reads knowledge-base.md and references/<db>.md
4. It returns the output envelope (diagnosis + 1–3 candidate queries)
5. You save the winner back into the folder as refined.sql
6. The agent appends a lesson to knowledge-base.md
```

### Mode B — Batch (CSV/XLS driven)

Your C# orchestrator walks a CSV/XLS index:

```
usecase_id, db_type, folder_path, priority, owner, notes
LOAN-001,   teradata, usecases/loan-lookup,    P1, balaji, "50-loan multi-value"
LOAN-002,   oracle,   usecases/loan-history,   P2, balaji, "current + history union"
...
```

For each row, the orchestrator:

1. Loads the folder contents into the input envelope.
2. Sends `system-prompt.md` + `knowledge-base.md` + `references/<db>.md` + envelope to Claude.
3. Writes the returned refined SQL to `<folder>/refined.sql` (and up to two alternates as `refined-alt1.sql`, `refined-alt2.sql`).
4. Merges the returned "lesson" block into `knowledge-base.md`.

---

## 4. Where C# fits (Atlas/AIDA integration)

You'd add a small `SqlTuningRunner` service that:

- Reads the CSV/XLS index (ClosedXML or CsvHelper).
- For each row, loads the use-case folder into an `InputEnvelope` DTO.
- Calls the Claude API with `system-prompt.md` as the system message and the envelope as the user message.
- Parses the fenced JSON response into `OutputEnvelope`.
- Writes candidates to disk and appends `lesson` to `knowledge-base.md` under a file lock.
- Records the run in `agent_run.plan_evidence` (matches your existing Atlas pattern from the model-gateway work).

The prompt is deliberately dialect-agnostic about *how* it's called — you can drop this same folder into any host.

---

## 5. Non-goals and hard rules

- **DML only, and only read-shaped DML.** The agent produces `SELECT`, `WITH ... SELECT`, and (where allowed) session-scoped temp tables that end in a `SELECT`. No `INSERT` / `UPDATE` / `DELETE` / `MERGE` / DDL / grants / procedures.
- **The last statement must return the same result set as the original.** Row equivalence is the contract; performance is the goal.
- **No fabricated columns or tables.** If the DDL doesn't show it, the agent doesn't invent it — it flags the gap in the diagnosis instead.
- **Parameter-shape aware.** A query tuned for `WHERE loan_no = ?` may not be optimal for `WHERE loan_no IN (?, ?, … ×50)`. The agent must consider both when `params.md` says so.
- **Current vs history awareness.** If the DDL/notes flag a table as `_HIST` or "SCD-2", the agent picks the right one (or unions correctly) and never scans history when a current-only view will do.

---

## 6. What to send Claude at call time

The exact message shape is in `templates/input-envelope.md`. The system message is `system-prompt.md` concatenated with `references/<db>.md` and `knowledge-base.md`. The user message is the filled input envelope.

## 7. Extending to a new database

1. Add `references/<newdb>.md` following the shape of the existing four.
2. Add its dialect to the `db_type` enum in `system-prompt.md` §2.
3. Add a canned example use-case under `examples/`.
4. Run the batch driver on a few real slow queries; watch what patterns land in `knowledge-base.md`. That is the file you actually learn from.
