// C# sketch: how the batch orchestrator hangs together. Not compiled here — this is
// a shape for you to adapt into Atlas/AIDA. It reads the CSV, walks each use case
// folder, calls Claude, and writes back refined.sql + updates knowledge-base.md.
//
// Uses: CsvHelper (CSV), Anthropic.SDK or plain HttpClient for the Claude API.
// Assumes: sql-tuning-agent/ is a folder path passed in.

using System.Text.Json;
using System.Text.Json.Serialization;

public sealed class SqlTuningRunner
{
    private readonly string _kitRoot;         // sql-tuning-agent/
    private readonly IClaudeClient _claude;
    private readonly SemaphoreSlim _kbLock = new(1, 1);

    public SqlTuningRunner(string kitRoot, IClaudeClient claude)
    {
        _kitRoot = kitRoot;
        _claude  = claude;
    }

    public async Task RunBatchAsync(string indexCsvPath, CancellationToken ct)
    {
        var rows = LoadIndex(indexCsvPath); // usecase_id, db_type, folder_path, ...
        foreach (var row in rows.Where(r => r.Priority == "P1" || r.Priority == "P2"))
        {
            try   { await RunOneAsync(row, ct); }
            catch (Exception ex) { LogFailure(row, ex); }
        }
    }

    public async Task RunOneAsync(UsecaseRow row, CancellationToken ct)
    {
        var folder = Path.Combine(_kitRoot, row.FolderPath);
        var input  = BuildInputEnvelope(row, folder);

        var systemMessage = string.Join("\n\n---\n\n",
            File.ReadAllText(Path.Combine(_kitRoot, "system-prompt.md")),
            File.ReadAllText(Path.Combine(_kitRoot, "references", $"{row.DbType}.md")),
            File.ReadAllText(Path.Combine(_kitRoot, "knowledge-base.md")));

        var userMessage = "```json\n" + JsonSerializer.Serialize(input, JsonOpts) + "\n```";

        var raw = await _claude.SendAsync(systemMessage, userMessage, ct);
        var envelope = ParseFencedJson<OutputEnvelope>(raw);

        WriteBackCandidates(folder, envelope);
        await AppendLessonAsync(envelope.Lesson, ct);
        File.WriteAllText(Path.Combine(folder, "run.json"),
            JsonSerializer.Serialize(new { input, output = envelope }, JsonOpts));
    }

    private static InputEnvelope BuildInputEnvelope(UsecaseRow row, string folder) => new()
    {
        UsecaseId    = row.UsecaseId,
        DbType       = row.DbType,
        ExistingSql  = ReadOrEmpty(folder, "existing.sql"),
        Ddl          = ReadOrEmpty(folder, "ddl.sql"),
        ExecutionPlan= ReadOrEmpty(folder, "plan.txt"),
        Params       = ParamsFromMarkdown(ReadOrEmpty(folder, "params.md")),
        Notes        = ReadOrEmpty(folder, "notes.md"),
        Constraints  = DefaultConstraints(),
    };

    private static void WriteBackCandidates(string folder, OutputEnvelope env)
    {
        if (env.Candidates.Count == 0) return;
        var main = env.Candidates.First(c => c.Id == env.Recommendation);
        File.WriteAllText(Path.Combine(folder, "refined.sql"), main.Sql);

        var alts = env.Candidates.Where(c => c.Id != env.Recommendation).Take(2).ToList();
        for (int i = 0; i < alts.Count; i++)
            File.WriteAllText(Path.Combine(folder, $"refined-alt{i + 1}.sql"), alts[i].Sql);
    }

    private async Task AppendLessonAsync(Lesson? lesson, CancellationToken ct)
    {
        if (lesson is null || lesson.DuplicateOf is not null) return;
        await _kbLock.WaitAsync(ct);
        try
        {
            var kbPath = Path.Combine(_kitRoot, "knowledge-base.md");
            var line = $"- [{lesson.Id}] {lesson.DbType} :: {lesson.Symptom} :: {lesson.Fix}\n" +
                       $"  before: `{lesson.ExampleBefore}`\n" +
                       $"  after:  `{lesson.ExampleAfter}`\n";
            var existing = await File.ReadAllTextAsync(kbPath, ct);
            if (existing.Contains($"[{lesson.Id}]")) return; // dedupe by id
            await File.AppendAllTextAsync(kbPath, "\n" + line, ct);
        }
        finally { _kbLock.Release(); }
    }

    // --- helpers ---
    private static readonly JsonSerializerOptions JsonOpts = new(JsonSerializerDefaults.Web)
    {
        WriteIndented = true,
        DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull
    };

    private static string ReadOrEmpty(string folder, string file)
        => File.Exists(Path.Combine(folder, file))
            ? File.ReadAllText(Path.Combine(folder, file)) : "";

    // Parse the single fenced ```json block the agent returns.
    private static T ParseFencedJson<T>(string raw)
    {
        var start = raw.IndexOf("```json", StringComparison.Ordinal);
        var end   = raw.LastIndexOf("```", StringComparison.Ordinal);
        var body  = raw[(start + 7)..end].Trim();
        return JsonSerializer.Deserialize<T>(body, JsonOpts)!;
    }

    private static ParamsBlock ParamsFromMarkdown(string md) => new(); // TODO: cheap parser
    private static Constraints  DefaultConstraints() => new()
    {
        MustPreserveOrder = true,
        AllowedShapes     = new[] { "single_select", "cte", "temp_table" }
    };

    private static List<UsecaseRow> LoadIndex(string path) => new(); // TODO: CsvHelper
    private static void LogFailure(UsecaseRow row, Exception ex) { /* wire to Atlas telemetry */ }
}

// --- DTOs (fields trimmed for brevity; match input-envelope.md / output-envelope.md) ---

public record UsecaseRow(string UsecaseId, string DbType, string FolderPath, string Priority, string Owner, string Notes);

public sealed class InputEnvelope
{
    public string UsecaseId { get; set; } = "";
    public string DbType    { get; set; } = "";
    public string ExistingSql { get; set; } = "";
    public string Ddl         { get; set; } = "";
    public string ExecutionPlan { get; set; } = "";
    public ParamsBlock Params { get; set; } = new();
    public List<TableFact> TableFacts { get; set; } = new();
    public Constraints Constraints    { get; set; } = new();
    public string Notes { get; set; } = "";
}

public sealed class ParamsBlock { /* shapes, notes */ }
public sealed class TableFact  { /* name, kind, approx_rows, primary_index, ... */ }
public sealed class Constraints
{
    public bool MustPreserveOrder { get; set; }
    public IEnumerable<string> AllowedShapes { get; set; } = Array.Empty<string>();
}

public sealed class OutputEnvelope
{
    public string UsecaseId { get; set; } = "";
    public string DbType    { get; set; } = "";
    public string Confidence { get; set; } = "";
    public string? Recommendation { get; set; }
    public List<Candidate> Candidates { get; set; } = new();
    public Lesson? Lesson { get; set; }
    public List<string> TestPlan { get; set; } = new();
    // Diagnosis omitted for brevity.
}

public sealed class Candidate
{
    public string Id { get; set; } = "";
    public string Shape { get; set; } = "";
    public List<string> BestFor { get; set; } = new();
    public string Sql { get; set; } = "";
    public string Rationale { get; set; } = "";
    public string ExpectedGain { get; set; } = "";
    public string Risk { get; set; } = "";
}

public sealed class Lesson
{
    public string Id { get; set; } = "";
    public string DbType { get; set; } = "";
    public string Symptom { get; set; } = "";
    public string Fix { get; set; } = "";
    public string ExampleBefore { get; set; } = "";
    public string ExampleAfter { get; set; } = "";
    public string? DuplicateOf { get; set; }
}

public interface IClaudeClient
{
    Task<string> SendAsync(string systemMessage, string userMessage, CancellationToken ct);
}
