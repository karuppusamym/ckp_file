# Reference: Teradata

## Dialect essentials
- Placeholders: `?` (positional).
- Identifiers: unquoted uppercase by default. Quote with double quotes only when case-sensitive.
- Dates: `DATE '2026-01-15'`, `TIMESTAMP '2026-01-15 10:00:00'`.
- Row limits: `TOP n` or `SAMPLE n`. `LIMIT` is **not** supported.
- Concatenation: `||`.
- Session-scoped temp: `CREATE VOLATILE TABLE ... ON COMMIT PRESERVE ROWS`. Drops at session end.

## Primary index (PI) — the whole game
Every table has a PI. Joins and access paths hang off it. Rules the agent must respect:
- If the join key equals the PI on **both** sides, you get an AMP-local join (cheap).
- If not, the smaller side is redistributed or duplicated across AMPs (expensive at scale).
- A CAST on the PI column disables PI use — see `TD-SARG-001` in knowledge base.

## Statistics
- Fresh stats on join columns and PI columns are essential. `COLLECT STATISTICS ON <table> COLUMN(<col>)`.
- On volatile tables that will be joined, collect stats **after** the insert, **before** the SELECT.

## Hints (use sparingly, always justify)
- `WITH RECURSIVE` — recursion.
- `DIAGNOSTIC HELPSTATS ON FOR SESSION;` — surface missing stats in EXPLAIN.
- No inline hint language like Oracle's `/*+ ... */`. Plan shaping is via stats, PI choice, and rewrite.

## Idiomatic rewrites
- **50-value IN-list slow?** Populate a small volatile table, collect stats, join.
- **Skewed hash join?** Repartition via a volatile table with a matching PI.
- **CTE materializes when you want inline (or vice-versa)?** Try a derived table; Teradata's optimizer treats them differently across releases.

## Anti-patterns
- `SELECT TOP 1 * FROM ... ORDER BY <non-indexed>` — adds a full sort. Add an index or accept the cost knowingly.
- `LEFT JOIN` where an `INNER` would do — Teradata still processes the outer side fully.
- `UNION` where `UNION ALL` is correct — the dedup sort is often the entire query cost.

## Formatting
- Uppercase reserved words.
- Prefer explicit column lists.
- Comment the PI at the top of every DDL block.
