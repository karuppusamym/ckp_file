# Reference: Oracle

## Dialect essentials
- Placeholders: `:name` (named). Positional `?` works with some drivers but named is canonical.
- Identifiers: unquoted uppercase; case-sensitive only when double-quoted.
- Dates: `DATE '2026-01-15'`, `TIMESTAMP '2026-01-15 10:00:00'`.
- Row limits: `FETCH FIRST n ROWS ONLY` (12c+), or `WHERE ROWNUM <= n` (pre-12c).
- Concatenation: `||`.
- Session-scoped temp: `CREATE PRIVATE TEMPORARY TABLE ORA$PTT_...` (18c+) or `CREATE GLOBAL TEMPORARY TABLE ... ON COMMIT PRESERVE ROWS` (pre-18c).

## The CBO and plan stability
- Bind peeking + adaptive cursor sharing decide plans per bind shape. A query fast for one loan_no can be slow for a common one.
- Fix plan drift with SQL plan baselines, not hints, when possible.

## Hints (justify each)
- `/*+ INLINE */` and `/*+ MATERIALIZE */` on a CTE — force evaluation mode.
- `/*+ USE_HASH(a b) */` — force hash join for large-large.
- `/*+ USE_NL(a b) */` — force nested loop for tiny driver × indexed large.
- `/*+ LEADING(a b c) */` — set join order when CE misestimates.
- `/*+ PARALLEL(n) */` — parallel scan; verify licensing and enable_parallel_query.
- `/*+ INDEX(t idx_name) */` — force a specific index.

## Idiomatic rewrites
- **Correlated subquery is slow?** Rewrite as JOIN or use `WITH` + aggregation.
- **`NOT IN` with nulls?** Rewrite as `NOT EXISTS` — semantics differ if the subquery can return null.
- **Function on indexed column?** Add a function-based index or rewrite predicate to be sargable.
- **50-value IN-list?** `WHERE col IN (VALUES ...)` isn't Oracle; use a global temporary table, or a `WITH ids AS (SELECT :1 FROM DUAL UNION ALL ...)` for small lists.

## Anti-patterns
- `WHERE TRUNC(col) = DATE '...'` — rewrite as range.
- `SELECT * FROM big t WHERE ROWNUM = 1` without ORDER — nondeterministic, but sometimes intended; call it out.
- Cursor loops in PL/SQL for what is set logic — the agent doesn't emit PL/SQL, but flag it in diagnosis if present.

## Formatting
- Uppercase reserved words.
- End statements with `;`.
- One column per line for wide projections.
