# Reference: PostgreSQL

## Dialect essentials
- Placeholders: `$1`, `$2`, ... (positional) or `:name` via drivers; the agent should emit `:name` by convention.
- Identifiers: unquoted are folded to lowercase; double-quote to preserve case.
- Dates: `DATE '2026-01-15'`, `TIMESTAMP '2026-01-15 10:00:00'`.
- Row limits: `LIMIT n OFFSET m`.
- Concatenation: `||`.
- Session-scoped temp: `CREATE TEMP TABLE ... ON COMMIT DROP` (per-transaction) or default (per-session).

## CTE materialization
- Pre-12: CTEs are always materialized (optimization fence). Reused CTEs win; single-use CTEs lose vs. a subquery.
- 12+: default is inline; force with `AS MATERIALIZED` or `AS NOT MATERIALIZED`.
- The agent must emit the explicit form on 12+ when materialization matters.

## Indexes (know the type)
- **B-tree** — default, equality and ranges.
- **Hash** — equality only; useful in 10+.
- **GIN** — arrays, JSONB, full-text.
- **GiST / SP-GiST** — geometric, range types.
- **BRIN** — huge tables physically ordered by the indexed column (time-series wins big here).
- **Functional / partial indexes** — for `WHERE lower(email) = ?` or `WHERE deleted_at IS NULL`.

## Idiomatic rewrites
- **`NOT IN` on nullable column?** Always `NOT EXISTS`.
- **`OR` across columns disables indexes?** Split into `UNION ALL` of two indexed queries.
- **Big offset paging?** Switch to keyset pagination (`WHERE (created_at, id) < (?, ?)`).
- **50-value IN-list?** `= ANY(:ids::int[])` with a parameterized array is often best.
  ```sql
  SELECT ...
  FROM loan_current lc
  WHERE lc.loan_no = ANY(:loan_nos::bigint[]);
  ```

## Planner controls (session-level, justify)
- `SET LOCAL enable_seqscan = off;` — force index paths; only in a transaction, only when the plan is wrong.
- `SET LOCAL enable_nestloop = off;` — force hash/merge; useful when nested loop is chosen on 10M×10M.
- `SET LOCAL work_mem = '256MB';` — allow larger hash / sort in memory for this transaction.
- Prefer stats refresh (`ANALYZE`) and index changes over planner toggles.

## Extensions worth naming
- `pg_stat_statements` — top-N slow queries.
- `pg_hint_plan` — hint syntax comparable to Oracle's; not core.
- `pg_trgm` — trigram indexes for `LIKE '%x%'`.

## Anti-patterns
- `SELECT ... ORDER BY random() LIMIT n` — sorts the entire table.
- `DISTINCT` to hide a bad join.
- `count(*)` on giant tables without a `WHERE` — use `pg_class.reltuples` for approximate counts.

## Formatting
- Uppercase reserved words.
- Lowercase identifiers (matches Postgres folding).
- Explicit `INNER JOIN` / `LEFT JOIN`.
