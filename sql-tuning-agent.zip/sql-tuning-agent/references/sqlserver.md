# Reference: SQL Server (T-SQL)

## Dialect essentials
- Placeholders: `?` (ODBC) or `@name` (native).
- Identifiers: unquoted are case-insensitive at DB default collation; bracket for reserved words: `[order]`.
- Dates: `'2026-01-15'` cast to `DATE`/`DATETIME2` — prefer `CAST('2026-01-15' AS DATE)`.
- Row limits: `TOP n` or `OFFSET n ROWS FETCH NEXT m ROWS ONLY`.
- Concatenation: `+` (dangerous with NULLs) — prefer `CONCAT()`.
- Session-scoped temp: `#temp` (drops at session/proc end). `##global_temp` shared across sessions — avoid.
- Local table variable: `@t` — no statistics; use `#temp` when volume matters.

## Plan cache & parameter sniffing
- Plans are cached by parameterized text. Sniffing means the plan is compiled for the first bind values seen — often wrong for later calls.
- Mitigations:
  - `OPTION (RECOMPILE)` — recompile every call. Cheap for small queries, expensive at high call rates.
  - `OPTION (OPTIMIZE FOR UNKNOWN)` — average density; safe when distribution is uniform.
  - `OPTION (OPTIMIZE FOR (@p = <value>))` — pin to a good bind.
  - Query Store + Forced Plan — best long-term fix.

## Hints (justify each)
- `WITH (NOLOCK)` — dirty reads; almost never worth the correctness cost. Do not emit unless caller explicitly allows.
- `WITH (INDEX(ix_name))` — force index.
- `OPTION (HASH JOIN)` / `OPTION (LOOP JOIN)` / `OPTION (MERGE JOIN)` — force join type.
- `OPTION (MAXDOP n)` — parallelism cap.
- `OPTION (FORCE ORDER)` — respect the order in FROM.

## Idiomatic rewrites
- **CTE reused ≥2 times?** Materialize with `#temp` (SQL Server's CTEs always inline).
- **Table variable slow?** Move to `#temp` for stats.
- **Bad plan sniffed?** `OPTION (RECOMPILE)` on the specific slow statement, not the whole proc.
- **50-value IN-list?** Use a TVP (table-valued parameter) or a `VALUES` derived table joined to the target.
  ```sql
  SELECT ...
  FROM (VALUES (?), (?), ...) AS ids(loan_no)
  INNER JOIN loan_current lc ON lc.loan_no = ids.loan_no;
  ```

## Anti-patterns
- `SELECT COUNT(*) ... WHERE EXISTS (...)` — use `IF EXISTS` for control flow.
- `WHERE CONVERT(varchar, col) = ?` — non-sargable.
- Scalar UDFs in WHERE — force row-by-row; inline or rewrite as CTE.

## Formatting
- Uppercase reserved words.
- Explicit `INNER JOIN` / `LEFT JOIN`.
- Terminate with `;` and use `SET NOCOUNT ON;` at the top of multi-statement scripts if the caller reads counts.
