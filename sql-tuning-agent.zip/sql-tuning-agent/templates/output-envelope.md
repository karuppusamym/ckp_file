# Output envelope

The agent responds with **exactly one** fenced ```json block matching this schema. No prose outside the block.

```json
{
  "usecase_id": "LOAN-001",
  "db_type": "teradata",
  "diagnosis": {
    "restated_intent": "One sentence describing what the query computes.",
    "driving_table": "LOAN_CURRENT",
    "root_causes": [
      {
        "id": "RC1",
        "category": "predicate_not_sargable",
        "detail": "WHERE CAST(loan_no AS VARCHAR(20)) = ? disables the primary index on LOAN_NO."
      }
    ],
    "other_factors": [
      { "category": "history_overscan", "detail": "LOAN_HIST joined without EFF_END_DT = '9999-12-31' — full history scan for a point-in-time read." }
    ],
    "parameter_shape_impact": "Single-value: 1 seek row. Multi-value (50): 50 seeks or one index range — index still usable if predicate rewritten.",
    "assumptions": [
      "LOAN_HIST is not needed for this query — DDL shows current data on LOAN_CURRENT."
    ],
    "blockers": []
  },
  "confidence": "high",
  "recommendation": "C1",
  "candidates": [
    {
      "id": "C1",
      "shape": "single_select",
      "best_for": ["single", "multi"],
      "sql": "SELECT\n  lc.LOAN_NO,\n  lc.BRANCH_ID,\n  lc.STATUS_CD,\n  lc.PRINCIPAL_BAL\nFROM LOAN_CURRENT lc\nWHERE lc.LOAN_NO IN (?);",
      "rationale": "Drop the CAST so the primary index on LOAN_NO is used; drop the LOAN_HIST join because DDL shows LOAN_CURRENT carries all required columns.",
      "expected_gain": "10-100x on single-value; 5-20x on 50-value IN-list.",
      "risk": "None if LOAN_CURRENT truly covers the columns; verify against caller.",
      "dialect_hints_used": [],
      "notes": "Row-equivalence preserved: same 4 columns, same predicate semantics."
    },
    {
      "id": "C2",
      "shape": "cte",
      "best_for": ["multi"],
      "sql": "WITH loans AS (\n  SELECT LOAN_NO\n  FROM (SELECT ? AS LOAN_NO) params\n)\nSELECT\n  lc.LOAN_NO,\n  lc.BRANCH_ID,\n  lc.STATUS_CD,\n  lc.PRINCIPAL_BAL\nFROM LOAN_CURRENT lc\nINNER JOIN loans p ON p.LOAN_NO = lc.LOAN_NO;",
      "rationale": "Materializes the parameter list as a driving set — helps when the IN-list grows past a few hundred and the optimizer picks a hash join.",
      "expected_gain": "Comparable to C1 for ≤ 50; better for very large lists.",
      "risk": "CTE may inline on some Teradata releases; verify plan.",
      "dialect_hints_used": [],
      "notes": ""
    }
  ],
  "lesson": {
    "id": "TD-SARG-001",
    "db_type": "teradata",
    "symptom": "primary index disabled by CAST on join/filter key",
    "fix": "remove the CAST, coerce the parameter side instead",
    "example_before": "WHERE CAST(loan_no AS VARCHAR(20)) = ?",
    "example_after": "WHERE loan_no = CAST(? AS DECIMAL(15,0))",
    "duplicate_of": null
  },
  "test_plan": [
    "Run C1 with single-value shape; confirm plan uses LOAN_NO primary index.",
    "Run C1 with 50-value IN-list; confirm plan still index-driven, not full scan.",
    "Diff row output of C1 vs. original for 10 sample loan numbers — must be identical."
  ]
}
```

## Semantics

- **confidence**: `high` | `medium` | `low`. `high` means one candidate is clearly best; the orchestrator can auto-apply. `medium` / `low` means a human should review.
- **recommendation**: the `id` of the candidate the agent recommends. Absent iff `candidates` is empty.
- **candidates[].shape**: `single_select` | `cte` | `temp_table` | `union_all` — matches `constraints.allowed_shapes`.
- **candidates[].best_for**: which parameter shape(s) this candidate is best for; a list is fine (the same query is often best for both).
- **candidates[].sql**: the full script. Must end in a `SELECT` that returns the required projection. Formatted per `system-prompt.md` §4.
- **candidates[].dialect_hints_used**: named hints introduced by the rewrite (e.g. `["USE_HASH", "PARALLEL(8)"]` on Oracle). Justify each in `rationale`.
- **lesson**: one compact learning to append to `knowledge-base.md`. `duplicate_of` names the existing lesson id if this pattern is already recorded.
- **test_plan**: 2–5 short verification steps the orchestrator (or human) can run.

## Failure mode

If no candidate can be produced (e.g. DDL missing for a critical table), return:

```json
{
  "usecase_id": "...",
  "db_type": "...",
  "diagnosis": { "...": "...", "blockers": ["DDL for LOAN_HIST missing — cannot verify effective-date predicate."] },
  "confidence": "low",
  "recommendation": null,
  "candidates": [],
  "lesson": null,
  "test_plan": []
}
```
