# What goes in a use-case folder

Each row in `templates/usecase-index.csv` points at one folder. The folder must contain these files (empty is allowed for optional ones — the agent handles gaps).

```
usecases/<name>/
├── existing.sql   [required]  the current slow query, verbatim
├── ddl.sql        [required]  CREATE TABLE / VIEW / INDEX for every touched object
├── plan.txt       [recommended] dialect-native EXPLAIN output
├── params.md      [required]  parameter shapes (single, multi), example values, notes on cardinality/skew
├── notes.md       [optional]  any human context — deadlines, prior attempts, known constraints
├── refined.sql    [produced]  the agent's recommended query (writes back)
├── refined-alt1.sql [produced] optional alternate
├── refined-alt2.sql [produced] optional alternate
└── run.json       [produced]  full input+output envelope for this run, for audit
```

## Minimum-viable file contents

### existing.sql
The full slow query, formatted or not — the agent will re-format on output.

### ddl.sql
```sql
CREATE TABLE LOAN_CURRENT (
  LOAN_NO      DECIMAL(15,0) NOT NULL,
  BRANCH_ID    INTEGER,
  STATUS_CD    CHAR(2),
  PRINCIPAL_BAL DECIMAL(18,2),
  PRIMARY INDEX (LOAN_NO)
);
-- one CREATE per touched table, view, index. Include row-count comment if known:
--   ROW_COUNT: ~4.2M
```

### plan.txt
Paste the EXPLAIN output. For Teradata: `EXPLAIN <query>`. For Oracle: `EXPLAIN PLAN` + `DBMS_XPLAN.DISPLAY`. For SQL Server: actual execution plan XML or the text plan. For PostgreSQL: `EXPLAIN (ANALYZE, BUFFERS)` preferred, plain `EXPLAIN` acceptable.

### params.md
```markdown
## Shapes
- single: loan_no = 0001234567
- multi:  loan_no IN (0001234567, ..., 0009999999) — typically 50, sometimes up to 500

## Cardinality
- ~1 row per loan_no in LOAN_CURRENT
- ~90 rows per loan_no in LOAN_HIST

## Skew
- 0.3% of loan numbers concentrate 40% of history rows (branch 0001).
```

### notes.md
Anything a human tuner would tell the agent: "the CTE version was tried and got worse", "we can't add indexes", "this runs at 3am and has a 5-min budget", etc.
