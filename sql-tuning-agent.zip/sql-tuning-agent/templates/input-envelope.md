# Input envelope

The user-message to the agent is a single fenced ```json block matching this schema. Load each field from the corresponding file in the use-case folder.

```json
{
  "usecase_id": "LOAN-001",
  "db_type": "teradata",
  "existing_sql": "<full text of usecases/<name>/existing.sql>",
  "ddl": "<full text of usecases/<name>/ddl.sql — CREATE TABLE / VIEW / INDEX statements for every object the query touches>",
  "execution_plan": "<full text of usecases/<name>/plan.txt — EXPLAIN output; empty string if not available>",
  "params": {
    "shapes": [
      { "name": "single", "example": { "loan_no": "0001234567" } },
      { "name": "multi",  "example": { "loan_no": ["0001234567", "...", "0009999999"], "count": 50 } }
    ],
    "notes": "<free text from usecases/<name>/params.md — anything the tuner should know about parameter distribution, skew, typical cardinality>"
  },
  "table_facts": [
    {
      "name": "LOAN_CURRENT",
      "kind": "current",
      "approx_rows": 4200000,
      "primary_index": ["LOAN_NO"],
      "secondary_indexes": [["BRANCH_ID", "STATUS_CD"]],
      "partitioned_by": null,
      "notes": "point-in-time snapshot"
    },
    {
      "name": "LOAN_HIST",
      "kind": "history",
      "approx_rows": 380000000,
      "primary_index": ["LOAN_NO", "EFF_START_DT"],
      "partitioned_by": "EFF_START_DT (monthly)",
      "scd_type": 2,
      "notes": "one row per change; EFF_END_DT = 9999-12-31 for current"
    }
  ],
  "constraints": {
    "must_return_columns": ["LOAN_NO", "BRANCH_ID", "STATUS_CD", "PRINCIPAL_BAL"],
    "must_preserve_order": true,
    "allowed_shapes": ["single_select", "cte", "temp_table"],
    "forbidden_features": ["hints_without_justification"]
  },
  "prior_lessons_hint": "<optional; the orchestrator may pre-select top-N lesson ids from knowledge-base.md to focus attention>",
  "notes": "<free text from usecases/<name>/notes.md — any human context the tuner would give the agent>"
}
```

## Field-by-field

- **usecase_id** — stable id, matches the CSV/XLS row.
- **db_type** — `teradata` | `oracle` | `sqlserver` | `postgres`.
- **existing_sql** — the current slow query, verbatim.
- **ddl** — CREATE TABLE / VIEW / INDEX for every object the query touches. The more complete this is, the better the diagnosis.
- **execution_plan** — dialect-native EXPLAIN. Optional but recommended.
- **params.shapes** — one entry per shape the query is expected to serve. At minimum include the single-value shape; add multi-value shapes when the query is called with lists. The agent must consider every shape listed.
- **table_facts** — row counts, indexes, partitioning, `kind` (`current` / `history` / `staging`), and any SCD notes. If you don't know a row count, use `null` and the agent will assume large.
- **constraints.must_return_columns** — the projection the caller depends on. The agent must return exactly these columns in this order.
- **constraints.allowed_shapes** — restrict the shapes the agent may emit. Default is all three.
- **constraints.forbidden_features** — extra guardrails per use case.
- **prior_lessons_hint** — optional; if the orchestrator pre-selects relevant lessons from `knowledge-base.md`, pass their ids here.
- **notes** — free text.

## How the orchestrator assembles the message

1. **System message** = `system-prompt.md` + `\n\n---\n\n` + `references/<db_type>.md` + `\n\n---\n\n` + `knowledge-base.md`.
2. **User message** = the JSON envelope above, wrapped in a `\`\`\`json` fence.
