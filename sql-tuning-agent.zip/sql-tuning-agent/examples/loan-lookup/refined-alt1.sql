-- Refined C2 (alternate; best for >200-value lists).
-- Uses a volatile table with stats so the optimizer picks a merge-join to LOAN_CURRENT on PI.

CREATE VOLATILE TABLE ids
(
    LOAN_NO DECIMAL(15,0) NOT NULL
) PRIMARY INDEX (LOAN_NO)
ON COMMIT PRESERVE ROWS;

INSERT INTO ids (LOAN_NO) VALUES (?);
-- (Orchestrator: repeat INSERT once per input loan_no; or use multi-statement request.)

COLLECT STATISTICS ON ids COLUMN(LOAN_NO);

SELECT
    lc.LOAN_NO,
    lc.BRANCH_ID,
    lc.STATUS_CD,
    lc.PRINCIPAL_BAL
FROM LOAN_CURRENT lc
INNER JOIN ids i
    ON i.LOAN_NO = lc.LOAN_NO;
