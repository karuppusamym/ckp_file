-- LOAN-001: 50-loan lookup, current status + latest balance
-- Runs against Teradata; typical latency 45-120s, expected <2s.

SELECT DISTINCT
    lc.LOAN_NO,
    lc.BRANCH_ID,
    lc.STATUS_CD,
    lh.PRINCIPAL_BAL
FROM LOAN_CURRENT lc
LEFT JOIN LOAN_HIST lh
    ON CAST(lh.LOAN_NO AS VARCHAR(20)) = CAST(lc.LOAN_NO AS VARCHAR(20))
WHERE CAST(lc.LOAN_NO AS VARCHAR(20)) IN (?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
                                          ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
                                          ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
                                          ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
                                          ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
