## Shapes
- single: loan_no = 0001234567
- multi:  loan_no IN (?, ..., ?) — always 50 in production; occasionally up to 200 in ad-hoc.

## Cardinality
- 1 row per loan_no in LOAN_CURRENT (LOAN_NO is unique).
- ~90 rows per loan_no in LOAN_HIST across time; typically 1 current row (EFF_END_DT = '9999-12-31').

## Skew
- Loan numbers concentrate under a handful of high-volume branches; no skew relevant to this predicate.

## Caller contract
- Must return exactly these columns, in this order: LOAN_NO, BRANCH_ID, STATUS_CD, PRINCIPAL_BAL.
- Row count expected: `= count(input loan_no set)` when all exist; missing loan_nos may return zero rows for that entry (LEFT semantics on the caller side is handled downstream).
