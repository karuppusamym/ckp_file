-- Refined C1 (recommended). Diagnosis: primary index disabled by CAST; unnecessary LOAN_HIST join.
-- Row-equivalence: same 4 columns, same semantics (DISTINCT dropped as LOAN_NO is unique in LOAN_CURRENT).

SELECT
    lc.LOAN_NO,
    lc.BRANCH_ID,
    lc.STATUS_CD,
    lc.PRINCIPAL_BAL
FROM LOAN_CURRENT lc
WHERE lc.LOAN_NO IN (?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
                     ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
                     ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
                     ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
                     ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
